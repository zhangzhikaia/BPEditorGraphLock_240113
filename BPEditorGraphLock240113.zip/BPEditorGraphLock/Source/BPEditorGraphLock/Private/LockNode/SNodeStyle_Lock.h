﻿// Copyright lurongjiu. All Rights Reserved.

#pragma once

#include "EdGraphNode_Lock.h"
#include "SGraphNode.h"

class SNodeStyle_Lock : public SGraphNode
{
public:

	SLATE_BEGIN_ARGS(SNodeStyle_Lock){}
	
	SLATE_END_ARGS()
	
	void Construct(const FArguments& InArgs,UEdGraphNode_Lock* InNode);
	
private:
	
	// SGraphNode interface
	virtual void UpdateGraphNode() override; 
	// End of SGraphNode interface
		
	virtual void Tick( const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime ) override;

	void CheckAndBindDelegate();
	
	void EventSelectionChanged(const FGraphPanelSelectionSet& GraphPanelSelectionSet);
	
	bool IsOnSelectionChangedBinded;
};
