﻿// Copyright lurongjiu. All Rights Reserved.

#include "SNodeStyle_Lock.h"

#include "DebugHeader.h"
#include "SCommentBubble.h"
#include "SGraphPanel.h"
#include "InputCoreTypes.h"
#include "GraphEditor.h"
#include "Widgets/SNullWidget.h"

void SNodeStyle_Lock::Construct(const FArguments& InArgs, UEdGraphNode_Lock* InNode)
{
	IsOnSelectionChangedBinded = false;
	
	GraphNode = InNode;
	
	InNode->SetWidget(SharedThis(this));

	SetCanTick(true);
	
	UpdateGraphNode(); 
}

void SNodeStyle_Lock::UpdateGraphNode()
{
	/*Clear*/
	InputPins.Empty();
	OutputPins.Empty();
	RightNodeBox.Reset();
	LeftNodeBox.Reset();

	/*Construct NullWidget*/
	this->GetOrAddSlot( ENodeZone::Center )
	.SlotSize(FVector2D(0.f)) 
	.HAlign(HAlign_Center)
	.VAlign(VAlign_Center)
	[
		SNullWidget::NullWidget
	];
}

void SNodeStyle_Lock::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	CheckAndBindDelegate();
}

void SNodeStyle_Lock::CheckAndBindDelegate()
{
	if(IsOnSelectionChangedBinded == false)
	{
		if(GetOwnerPanel().IsValid())
		{
			IsOnSelectionChangedBinded = true;
			
			GetOwnerPanel()->SelectionManager.OnSelectionChanged.BindSP(this,&SNodeStyle_Lock::EventSelectionChanged);
			SetCanTick(false);
		}
	}
}

void SNodeStyle_Lock::EventSelectionChanged(const FGraphPanelSelectionSet& GraphPanelSelectionSet)
{
	if(GetOwnerPanel().IsValid())
	{
		if(GraphPanelSelectionSet.Contains(GraphNode))
		{
			GetOwnerPanel()->SelectionManager.SelectedNodes.Remove(GraphNode);
		}
	}
}
